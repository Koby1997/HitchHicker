package com.example.lucas.myfirstapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class RideFilters extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ride_filters);
    }
//    public void Searching(View view)
//    {
//        //Home page layout
//
//            Intent intent = new Intent(this, Found.class);
//        if (false) {
//             intent = new Intent(this, NotFound.class);
//        }
//        startActivity(intent);
//    }

}
